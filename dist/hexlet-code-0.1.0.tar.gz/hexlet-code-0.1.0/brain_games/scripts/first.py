#! /usr/bin/env python3
import cli_1

cli_1.welcome_user()
