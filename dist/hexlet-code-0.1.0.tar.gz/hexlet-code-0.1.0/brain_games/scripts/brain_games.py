#! /usr/bin/env python3
def main():
    print('Welcome to brain games')

if __name__ == '__main__':
    main()
